package ru.netology.graphics.image;

public interface TextColorSchema {
    char convert(int color);
}
