package ru.netology.graphics.server;

import ru.netology.graphics.image.TextColorSchema;

public class Schema implements TextColorSchema {

    public Schema() {
    }

    @Override
    public char convert(int color) {
        char c = 'a';
        if (color >= 0 & color < 32) {c = '▇';}
        else if (color >= 32 & color < 64) {c = '●';}
        else if (color >= 64 & color < 96) {c = '◉';}
        else if (color >= 96 & color < 128) {c = '◍';}
        else if (color >= 128 & color < 160) {c = '◎';}
        else if (color >= 160 & color < 192 ) {c = '○';}
        else if (color >= 192 & color < 224 ) {c = '☉';}
        else if (color >= 224 & color < 255 ) {c = '◌';}

        return c;
    }
}
